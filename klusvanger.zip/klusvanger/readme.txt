=== KlusVanger ===
Thema voor de KlusVanger-site (one-page). Versie 1.0.0.

Installeren
1. Weergave > Thema's > Nieuw thema > Thema uploaden > klusvanger.zip > Activeren.
2. Instellingen > Lezen > "Je homepage toont": kies een statische pagina (maak een lege pagina "Home").
   De voorpagina gebruikt automatisch front-page.php.
3. Weergave > Customizer > KlusVanger: vul het KvK-nummer en contact-e-mailadres in.
4. Maak de pagina's "Privacy" (/privacy) en "Voorwaarden" (/voorwaarden).

Lettertypen
Bij activeren haalt het thema Archivo, Public Sans en IBM Plex Mono eenmalig op en zet ze in
/wp-content/uploads/klusvanger-fonts/. Bezoekers laden niets van Google (AVG).

Formulieren
Pilot- en partneraanmeldingen gaan naar het Supabase-endpoint (in te stellen in de Customizer).

<?php
/**
 * KlusVanger thema.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'KV_VERSION', '1.1.0' );
define( 'KV_ENDPOINT_DEFAULT', 'https://mssqeqqycmrrxeswcjmb.supabase.co/functions/v1/aanmelding' );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	register_nav_menus( array( 'footer' => __( 'Footer', 'klusvanger' ) ) );
} );

/* ---------- Instellingen in de Customizer (Weergave > Customizer > KlusVanger) ---------- */
add_action( 'customize_register', function ( $c ) {
	$c->add_section( 'kv', array( 'title' => 'KlusVanger', 'priority' => 30 ) );
	$fields = array(
		'kv_endpoint' => array( 'Aanmeld-endpoint (Supabase)', KV_ENDPOINT_DEFAULT ),
		'kv_kvk'      => array( 'KvK-nummer Salesify', '' ),
		'kv_email'    => array( 'Contact e-mailadres', '' ),
		'kv_privacy'  => array( 'URL privacyverklaring', '/privacy' ),
		'kv_terms'    => array( 'URL algemene voorwaarden', '/voorwaarden' ),
	);
	foreach ( $fields as $id => $f ) {
		$c->add_setting( $id, array( 'default' => $f[1], 'sanitize_callback' => 'sanitize_text_field' ) );
		$c->add_control( $id, array( 'label' => $f[0], 'section' => 'kv', 'type' => 'text' ) );
	}
} );

function kv_opt( $key, $default = '' ) {
	$v = get_theme_mod( $key, $default );
	return '' === $v ? $default : $v;
}

/* ---------- Lettertypen lokaal (AVG): eenmalig ophalen naar uploads, nooit vanaf Google laden voor bezoekers ---------- */
function kv_fonts_dir() {
	$u = wp_upload_dir();
	return array( 'path' => trailingslashit( $u['basedir'] ) . 'klusvanger-fonts/', 'url' => trailingslashit( $u['baseurl'] ) . 'klusvanger-fonts/' );
}

function kv_fetch_fonts() {
	$dir = kv_fonts_dir();
	if ( file_exists( $dir['path'] . 'fonts.css' ) ) { return true; }
	if ( ! wp_mkdir_p( $dir['path'] ) ) { return false; }
	$src = 'https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@100..125,500..800&family=IBM+Plex+Mono:wght@400;500&family=Public+Sans:wght@400;600;700&display=swap';
	$r   = wp_remote_get( $src, array( 'timeout' => 20, 'user-agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36' ) );
	if ( is_wp_error( $r ) || 200 !== wp_remote_retrieve_response_code( $r ) ) { return false; }
	$css = wp_remote_retrieve_body( $r );
	// Alleen latin-subsets houden.
	$blocks = preg_split( '/(?=\/\*)/', $css );
	$keep   = '';
	foreach ( $blocks as $b ) {
		if ( preg_match( '/^\/\*\s*latin\s*\*\//', trim( $b ) ) ) { $keep .= $b; }
	}
	if ( '' === $keep ) { $keep = $css; }
	if ( ! preg_match_all( '/url\((https:\/\/fonts\.gstatic\.com\/[^)]+\.woff2)\)/', $keep, $m ) ) { return false; }
	foreach ( array_unique( $m[1] ) as $i => $url ) {
		$file = 'f' . $i . '-' . substr( md5( $url ), 0, 8 ) . '.woff2';
		$fr   = wp_remote_get( $url, array( 'timeout' => 20 ) );
		if ( is_wp_error( $fr ) || 200 !== wp_remote_retrieve_response_code( $fr ) ) { return false; }
		file_put_contents( $dir['path'] . $file, wp_remote_retrieve_body( $fr ) );
		$keep = str_replace( $url, $dir['url'] . $file, $keep );
	}
	return false !== file_put_contents( $dir['path'] . 'fonts.css', $keep );
}
add_action( 'after_switch_theme', 'kv_fetch_fonts' );
add_action( 'admin_init', function () {
	if ( ! get_transient( 'kv_fonts_try' ) && ! file_exists( kv_fonts_dir()['path'] . 'fonts.css' ) ) {
		set_transient( 'kv_fonts_try', 1, HOUR_IN_SECONDS );
		kv_fetch_fonts();
	}
} );

/* ---------- Scripts en stijlen ---------- */
add_action( 'wp_enqueue_scripts', function () {
	$fonts = kv_fonts_dir();
	if ( file_exists( $fonts['path'] . 'fonts.css' ) ) {
		wp_enqueue_style( 'kv-fonts', $fonts['url'] . 'fonts.css', array(), KV_VERSION );
	}
	wp_enqueue_style( 'kv', get_stylesheet_uri(), array(), KV_VERSION );
	wp_enqueue_script( 'kv', get_template_directory_uri() . '/assets/js/klusvanger.js', array(), KV_VERSION, array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_localize_script( 'kv', 'KV', array( 'endpoint' => esc_url_raw( kv_opt( 'kv_endpoint', KV_ENDPOINT_DEFAULT ) ) ) );
} );

/* Overbodige WordPress-scripts op de voorkant weg: sneller laden. */
add_action( 'init', function () {
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'wp_generator' );
} );
add_action( 'wp_enqueue_scripts', function () {
	if ( is_front_page() ) {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'classic-theme-styles' );
	}
}, 100 );

/* ---------- SEO: beschrijving, Open Graph en gestructureerde gegevens ---------- */
add_action( 'wp_head', function () {
	if ( ! is_front_page() ) { return; }
	$desc = 'KlusVanger neemt je telefoon op als jij aan het werk bent en stuurt je binnen een minuut een complete klusaanvraag. Voor installateurs en loodgieters. 14 dagen gratis, daarna vanaf € 149 per maand.';
	echo '<meta name="description" content="' . esc_attr( $desc ) . "\">\n";
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<meta property="og:title" content="KlusVanger: mis geen klus meer als je de telefoon niet kunt opnemen">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . "\">\n";
	echo '<meta property="og:url" content="' . esc_url( home_url( '/' ) ) . "\">\n";
	echo '<meta property="og:locale" content="nl_NL">' . "\n";
	echo '<meta name="theme-color" content="#0E4A43">' . "\n";
	$ld = array(
		'@context'            => 'https://schema.org',
		'@type'               => 'SoftwareApplication',
		'name'                => 'KlusVanger',
		'applicationCategory' => 'BusinessApplication',
		'operatingSystem'     => 'Web, telefoon',
		'description'         => $desc,
		'offers'              => array( '@type' => 'AggregateOffer', 'lowPrice' => '149.00', 'highPrice' => '249.00', 'priceCurrency' => 'EUR', 'offerCount' => 2, 'description' => 'Per maand, exclusief btw. 14 dagen gratis.' ),
		'provider'            => array( '@type' => 'Organization', 'name' => 'Salesify' ),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $ld, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
}, 1 );

add_action( 'wp_head', function () {
	$svg = "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='7' fill='%230E4A43'/><path d='M9 7h4v7.5L19.5 7H24l-7 7.6L24.5 25H20l-5.3-7.6L13 19.2V25H9z' fill='%23F3B80C'/></svg>";
	echo '<link rel="icon" href="data:image/svg+xml,' . $svg . '">' . "\n";
}, 2 );

/* ---------- Kleine helpers voor de templates ---------- */
function kv_icon( $name ) {
	$i = array(
		'check'  => '<path d="M5 12.5l4.2 4.2L19 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
		'cross'  => '<path d="M7 7l10 10M17 7L7 17" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
		'phone'  => '<path d="M6.6 3.5h3l1.5 4.2-2 1.5a12 12 0 0 0 5.7 5.7l1.5-2 4.2 1.5v3a2 2 0 0 1-2.2 2A17 17 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
		'fwd'    => '<path d="M4 12h12M12 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M20 5v14" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
		'talk'   => '<path d="M4 5h16v10H9l-5 4z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M8 9h8M8 12h5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
		'bon'    => '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M9 8h6M9 12h6M9 16h3" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
		'warn'   => '<path d="M12 3l10 18H2z" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linejoin="round"/><path d="M12 10v5M12 18v.5" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
	);
	return '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">' . ( isset( $i[ $name ] ) ? $i[ $name ] : '' ) . '</svg>';
}

function kv_logo() {
	return '<svg viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="7" fill="#0E4A43"/><path d="M9 7h4v7.5L19.5 7H24l-7 7.6L24.5 25H20l-5.3-7.6L13 19.2V25H9z" fill="#F3B80C"/></svg>';
}

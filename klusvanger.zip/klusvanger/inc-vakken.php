<?php
/* Vakken: één product, per vak eigen voorbeelden, eigen pagina en eigen assistent-instellingen. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function kv_vakken() {
	return array(
		'installateurs' => array(
			'naam' => 'Installateurs en loodgieters', 'kort' => 'Installateur', 'bedrijf' => 'Installatiebedrijf De Vries', 'mensen' => 'monteurs',
			'hero' => 'Je ligt onder een gootsteen. De telefoon gaat.',
			'bon'  => array( 'Lekkage', 'Water uit het plafond onder de badkamer, blijft druppelen', '3561 AB Utrecht', 'S. Jansen', true ),
			'pijn' => 'Lekkages, cv-storingen en verstoppingen: klanten met spoed bellen door tot iemand opneemt.',
			'scen' => array(
				'lekkage' => array( 'Lekkage met spoed', array( 'klus' => 'Er komt water uit het plafond onder de badkamer, het blijft lopen', 'plaats' => '3561 AB Utrecht', 'naam' => 'Met Sanne Jansen' ) ),
				'cv'      => array( 'Cv-ketel in storing', array( 'klus' => 'Mijn cv-ketel geeft een storing, F28 staat op het scherm', 'spoed' => 'Het kan morgen ook nog', 'plaats' => 'Amersfoort', 'naam' => 'Peter de Boer' ) ),
				'gas'     => array( 'Ruikt gas', array( 'klus' => 'Ik ruik gas in de keuken' ) ),
			),
		),
		'elektriciens' => array(
			'naam' => 'Elektriciens', 'kort' => 'Elektricien', 'bedrijf' => 'Elektrotechniek Bakker', 'mensen' => 'monteurs',
			'hero' => 'Je zit met je handen in een meterkast. De telefoon gaat.',
			'bon'  => array( 'Stroomstoring', 'Aardlekschakelaar slaat steeds uit, halve huis zonder stroom', '2011 KL Haarlem', 'M. de Wit', true ),
			'pijn' => 'Stroom uit, groepen die uitslaan, laadpalen en zonnepanelen: wie niet opneemt, mist de klus.',
			'scen' => array(
				'storing' => array( 'Stroom uitgevallen', array( 'klus' => 'De aardlekschakelaar slaat steeds uit, we hebben geen stroom in de keuken', 'plaats' => '2011 KL Haarlem', 'naam' => 'Mark de Wit' ) ),
				'laadpaal' => array( 'Offerte laadpaal', array( 'klus' => 'Ik wil een offerte voor een laadpaal bij mijn huis', 'spoed' => 'Nee, geen haast', 'plaats' => 'Hoofddorp', 'naam' => 'Lisa Vos' ) ),
				'rook'    => array( 'Ruikt brandlucht', array( 'klus' => 'Ik ruik brandlucht bij de meterkast en zie een vonk' ) ),
			),
		),
		'slotenmakers' => array(
			'naam' => 'Slotenmakers', 'kort' => 'Slotenmaker', 'bedrijf' => 'Slotenservice Jansen', 'mensen' => 'monteurs',
			'hero' => 'Je bent een deur aan het openen. De telefoon gaat.',
			'bon'  => array( 'Buitengesloten', 'Sleutel afgebroken in de voordeur, staat buiten met kinderen', '3012 AB Rotterdam', 'A. Bakker', true ),
			'pijn' => 'Wie buitengesloten is, belt de eerste slotenmaker die opneemt. Niet de beste.',
			'scen' => array(
				'buiten' => array( 'Buitengesloten', array( 'klus' => 'Ik sta buiten, de sleutel is afgebroken in het slot van de voordeur', 'plaats' => '3012 AB Rotterdam', 'naam' => 'Anouk Bakker' ) ),
				'sloten' => array( 'Nieuwe sloten na verhuizing', array( 'klus' => 'Ik wil alle sloten laten vervangen, we zijn net verhuisd', 'spoed' => 'Deze week is prima', 'plaats' => 'Schiedam', 'naam' => 'Tom Visser' ) ),
			),
		),
		'dakdekkers' => array(
			'naam' => 'Dakdekkers', 'kort' => 'Dakdekker', 'bedrijf' => 'Dakwerken Mulder', 'mensen' => 'dakdekkers',
			'hero' => 'Je staat op een dak. De telefoon gaat.',
			'bon'  => array( 'Dak', 'Dakpannen weggewaaid, het lekt bij de schoorsteen', '8011 AA Zwolle', 'R. Smit', true ),
			'pijn' => 'Na een storm gaat de telefoon de hele dag. Jij staat dan zelf op een dak.',
			'scen' => array(
				'storm'  => array( 'Stormschade', array( 'klus' => 'Er zijn dakpannen van het dak gewaaid en het lekt bij de schoorsteen', 'plaats' => '8011 AA Zwolle', 'naam' => 'Rob Smit' ) ),
				'goot'   => array( 'Dakgoot vervangen', array( 'klus' => 'De dakgoot aan de achterkant moet vervangen worden', 'spoed' => 'Nee, het heeft geen haast', 'plaats' => 'Kampen', 'naam' => 'Ellen Kok' ) ),
			),
		),
		'ontstoppers' => array(
			'naam' => 'Ontstoppers en rioolservice', 'kort' => 'Ontstopper', 'bedrijf' => 'Rioolservice Peters', 'mensen' => 'monteurs',
			'hero' => 'Je staat tot je ellebogen in een afvoer. De telefoon gaat.',
			'bon'  => array( 'Afvoer', 'Wc en douche lopen niet meer door, water komt omhoog', '5611 AB Eindhoven', 'J. Peters', true ),
			'pijn' => 'Een verstopte wc kan niet wachten. De klant belt door tot iemand opneemt.',
			'scen' => array(
				'wc' => array( 'Wc verstopt', array( 'klus' => 'Onze wc is verstopt en het water komt omhoog', 'plaats' => '5611 AB Eindhoven', 'naam' => 'Jeroen Peters' ) ),
			),
		),
		'klusbedrijven' => array(
			'naam' => 'Timmerlieden en klusbedrijven', 'kort' => 'Timmerman / klusbedrijf', 'bedrijf' => 'Klusbedrijf Van Dam', 'mensen' => 'vakmensen',
			'hero' => 'Je zet een kozijn. De telefoon gaat.',
			'bon'  => array( 'Timmerwerk', 'Nieuwe kozijnen aan de achterkant, graag langskomen voor een offerte', '1811 AB Alkmaar', 'K. van Dam', false ),
			'pijn' => 'Elke gemiste oproep is een offerte die naar een ander gaat.',
			'scen' => array(
				'kozijn' => array( 'Offerte kozijnen', array( 'klus' => 'Ik wil een offerte voor nieuwe kozijnen aan de achterkant', 'spoed' => 'Nee, geen haast', 'plaats' => '1811 AB Alkmaar', 'naam' => 'Karin van Dam' ) ),
			),
		),
		'schilders' => array(
			'naam' => 'Schilders en stukadoors', 'kort' => 'Schilder / stukadoor', 'bedrijf' => 'Schildersbedrijf Hendriks', 'mensen' => 'schilders',
			'hero' => 'Je staat op een steiger met een kwast. De telefoon gaat.',
			'bon'  => array( 'Schilderwerk', 'Buitenschilderwerk vrijstaande woning, in het voorjaar', '6511 AB Nijmegen', 'P. Hendriks', false ),
			'pijn' => 'Met verf aan je handen neem je niet op. Die offerte gaat naar de concurrent.',
			'scen' => array(
				'buiten' => array( 'Offerte buitenschilderwerk', array( 'klus' => 'Ik wil een offerte voor buiten schilderwerk aan mijn huis', 'spoed' => 'Nee, in het voorjaar', 'plaats' => '6511 AB Nijmegen', 'naam' => 'Paul Hendriks' ) ),
			),
		),
		'hoveniers' => array(
			'naam' => 'Hoveniers', 'kort' => 'Hovenier', 'bedrijf' => 'Hoveniersbedrijf Groen', 'mensen' => 'hoveniers',
			'hero' => 'Je zit op de minigraver. De telefoon gaat.',
			'bon'  => array( 'Tuin', 'Nieuwe tuin met bestrating, ongeveer 60 m²', '7511 AB Enschede', 'N. Groen', false ),
			'pijn' => 'Buiten aan het werk, telefoon in je jas. Die tuinaanleg belt de volgende.',
			'scen' => array(
				'tuin' => array( 'Nieuwe tuin', array( 'klus' => 'Ik wil een nieuwe tuin met bestrating laten aanleggen', 'spoed' => 'Nee, geen haast', 'plaats' => '7511 AB Enschede', 'naam' => 'Nina Groen' ) ),
			),
		),
		'glaszetters' => array(
			'naam' => 'Glaszetters', 'kort' => 'Glaszetter', 'bedrijf' => 'Glashandel Vermeer', 'mensen' => 'glaszetters',
			'hero' => 'Je zet een ruit. De telefoon gaat.',
			'bon'  => array( 'Glasschade', 'Ruit van de voordeur kapot na een inbraakpoging', '2511 AB Den Haag', 'S. Vermeer', true ),
			'pijn' => 'Een kapotte ruit wacht niet. Wie het eerst opneemt, krijgt de klus.',
			'scen' => array(
				'ruit' => array( 'Kapotte ruit', array( 'klus' => 'De ruit van mijn voordeur is kapot na een inbraakpoging', 'plaats' => '2511 AB Den Haag', 'naam' => 'Sophie Vermeer' ) ),
			),
		),
	);
}

/* Huidig vak: op een vakpagina dat vak, anders null (algemene startpagina). */
function kv_vak() { return isset( $GLOBALS['kv_vak'] ) ? $GLOBALS['kv_vak'] : null; }
function kv_vak_data() { $v = kv_vak(); $all = kv_vakken(); return $v && isset( $all[ $v ] ) ? $all[ $v ] : null; }

/* Demo-scenario's voor JavaScript: per vak, of een mix op de startpagina. Altijd een prijsvraag erbij. */
function kv_vak_js() {
	$d = kv_vak_data();
	if ( $d ) { $scen = $d['scen']; $bedrijf = $d['bedrijf']; }
	else {
		$all = kv_vakken(); $scen = array();
		foreach ( array( 'installateurs' => 'lekkage', 'elektriciens' => 'storing', 'slotenmakers' => 'buiten', 'klusbedrijven' => 'kozijn' ) as $v => $k ) { $scen[ $v . '-' . $k ] = $all[ $v ]['scen'][ $k ]; }
		$scen['installateurs-gas'] = $all['installateurs']['scen']['gas'];
		$bedrijf = 'Vakbedrijf De Vries';
	}
	$out = array();
	foreach ( $scen as $k => $s ) {
		$a = array();
		foreach ( $s[1] as $f => $v ) { $a[ $f ] = array( $v ); }
		if ( isset( $a['plaats'] ) ) { $a['check'] = array( 'Ja, klopt' ); $a['nummer'] = array( 'Ja, dat nummer is goed' ); }
		$out[ $k ] = array( 'label' => $s[0], 'a' => $a );
	}
	$out['prijs'] = array( 'label' => 'Vraagt naar de prijs', 'a' => array( 'klus' => array( 'Wat kost het als jullie vandaag nog komen?' ), 'spoed' => array( 'Nee, morgen is ook goed' ), 'plaats' => array( 'Zeist' ), 'check' => array( 'Ja' ), 'naam' => array( 'Ruud Smit' ), 'nummer' => array( 'Ja' ) ) );
	return array( 'bedrijf' => $bedrijf, 'scen' => $out );
}

/* Vakpagina's: een WordPress-pagina met de slug van een vak toont de startpagina in dat vak. */
add_filter( 'template_include', function ( $t ) {
	if ( is_page() ) {
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		if ( isset( kv_vakken()[ $slug ] ) ) { $GLOBALS['kv_vak'] = $slug; return get_template_directory() . '/front-page.php'; }
	}
	return $t;
} );

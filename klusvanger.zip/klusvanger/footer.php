<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
$kvk   = kv_opt( 'kv_kvk' );
$email = kv_opt( 'kv_email' );
?>
<footer class="kv-footer">
	<div class="kv-wrap kv-footer__grid">
		<div style="display:flex;flex-direction:column;gap:.75rem;max-width:26rem">
			<a class="kv-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo kv_logo(); ?><span>KlusVanger</span></a>
			<p class="kv-small">KlusVanger is een dienst van Salesify<?php echo $kvk ? ' · KvK ' . esc_html( $kvk ) : ''; ?>.<?php if ( $email ) : ?> Vragen? <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a><?php endif; ?></p>
		</div>
		<nav aria-label="Voettekst">
			<a href="<?php echo esc_url( home_url( '/#prijs' ) ); ?>">Prijs</a>
			<a href="<?php echo esc_url( home_url( '/#vragen' ) ); ?>">Veelgestelde vragen</a>
			<a href="<?php echo esc_url( kv_opt( 'kv_privacy', '/privacy' ) ); ?>">Privacy</a>
			<a href="<?php echo esc_url( kv_opt( 'kv_terms', '/voorwaarden' ) ); ?>">Voorwaarden</a>
		</nav>
	</div>
</footer>
<div class="kv-mobilebar" data-kv-mobilebar>
	<a class="kv-btn kv-btn--ghost" href="<?php echo esc_url( home_url( '/#prijs' ) ); ?>">Prijzen</a>
	<a class="kv-btn kv-btn--primary" href="<?php echo esc_url( home_url( '/#aanmelden' ) ); ?>">14 dagen gratis</a>
</div>
<?php wp_footer(); ?>
</body>
</html>

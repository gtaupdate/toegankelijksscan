<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="kv-skip" href="#inhoud">Naar de inhoud</a>
<header class="kv-header" data-kv-header>
	<div class="kv-wrap kv-header__in">
		<a class="kv-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="KlusVanger, naar de startpagina">
			<?php echo kv_logo(); ?>
			<span class="kv-logo__text">KlusVanger<small>voor vakmensen</small></span>
		</a>
		<nav class="kv-nav" id="kv-nav" aria-label="Hoofdmenu">
			<a href="<?php echo esc_url( home_url( '/#zo-werkt-het' ) ); ?>">Zo werkt het</a>
			<a href="<?php echo esc_url( home_url( '/#probeer' ) ); ?>">Probeer het</a>
			<a href="<?php echo esc_url( home_url( '/#vergelijk' ) ); ?>">Vergelijk</a>
			<a href="<?php echo esc_url( home_url( '/#prijs' ) ); ?>">Prijzen</a>
			<a href="<?php echo esc_url( home_url( '/#vragen' ) ); ?>">Vragen</a>
			<?php if ( get_option( 'page_for_posts' ) ) : ?><a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>">Kennisbank</a><?php endif; ?>
			<a class="kv-btn kv-btn--primary kv-nav__cta" href="<?php echo esc_url( home_url( '/#aanmelden' ) ); ?>">14 dagen gratis proberen</a>
		</nav>
		<div class="kv-header__actions">
			<a class="kv-btn kv-btn--primary kv-header__cta" href="<?php echo esc_url( home_url( '/#aanmelden' ) ); ?>">14 dagen gratis</a>
			<button class="kv-menu" type="button" aria-controls="kv-nav" aria-expanded="false" data-kv-menu>
				<span class="kv-sr">Menu</span><span class="kv-menu__bars" aria-hidden="true"></span>
			</button>
		</div>
	</div>
</header>

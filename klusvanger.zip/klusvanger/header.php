<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="kv-skip" href="#inhoud">Naar de inhoud</a>
<header class="kv-header">
	<div class="kv-wrap kv-header__in">
		<a class="kv-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="KlusVanger, naar de startpagina"><?php echo kv_logo(); ?><span>KlusVanger</span></a>
		<nav class="kv-nav" aria-label="Hoofdmenu">
			<a href="<?php echo esc_url( home_url( '/#zo-werkt-het' ) ); ?>">Zo werkt het</a>
			<a href="<?php echo esc_url( home_url( '/#probeer' ) ); ?>">Probeer het</a>
			<a href="<?php echo esc_url( home_url( '/#rekenhulp' ) ); ?>">Rekenhulp</a>
			<a href="<?php echo esc_url( home_url( '/#prijs' ) ); ?>">Prijs</a>
			<a href="<?php echo esc_url( home_url( '/#vragen' ) ); ?>">Vragen</a>
		</nav>
		<a class="kv-btn kv-btn--primary" href="<?php echo esc_url( home_url( '/#aanmelden' ) ); ?>">Pilot aanvragen</a>
	</div>
</header>

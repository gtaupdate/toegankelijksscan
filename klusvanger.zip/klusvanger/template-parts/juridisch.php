<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
/* Juridische concepten. CONCEPT: laten controleren door een jurist voordat de site live gaat. */
$kv_kvk   = kv_opt( 'kv_kvk', '[KvK-nummer]' );
$kv_mail  = kv_opt( 'kv_email', '[e-mailadres]' );
$kv_doc   = isset( $kv_doc ) ? $kv_doc : 'privacy';
$kv_datum = '27 oktober 2026';
?>
<article class="kv-legal">
<p class="kv-legal__concept">Concept, versie <?php echo esc_html( $kv_datum ); ?></p>
<?php if ( 'privacy' === $kv_doc ) : ?>
<h1>Privacyverklaring</h1>
<p>KlusVanger is een dienst van Salesify (vof), KvK <?php echo esc_html( $kv_kvk ); ?>, bereikbaar via <?php echo esc_html( $kv_mail ); ?>. In deze verklaring lees je welke gegevens we verwerken, waarom, en welke rechten je hebt.</p>
<h2>1. Twee rollen</h2>
<p><b>Klanten van KlusVanger</b> (de vakbedrijven): voor hun account, abonnement en facturen zijn wij verwerkingsverantwoordelijke.</p>
<p><b>Mensen die een vakbedrijf bellen</b>: de assistent neemt namens het vakbedrijf op. Het vakbedrijf is dan verwerkingsverantwoordelijke en KlusVanger is verwerker. Vragen over een gesprek kun je het beste aan dat bedrijf stellen; wij helpen het bedrijf daarbij.</p>
<h2>2. Welke gegevens</h2>
<ul>
<li><b>Van klanten:</b> naam, bedrijfsnaam, rechtsvorm, e-mailadres, telefoonnummer, betaalgegevens (via Mollie), instellingen van de assistent.</li>
<li><b>Van bellers:</b> het nummer waarmee is gebeld, naam, adres of plaats, een korte omschrijving van de klus, of het spoed is en eventuele aandachtspunten. We bewaren <b>geen geluidsopnames</b> en <b>geen volledige gesprekken</b> in onze database.</li>
<li><b>Van websitebezoekers:</b> wat je invult in het aanmeldformulier, en een versleutelde (gehashte) vorm van je IP-adres om misbruik te voorkomen. We gebruiken geen trackingcookies.</li>
</ul>
<h2>3. Waarom en op welke grondslag</h2>
<ul>
<li>Uitvoeren van de overeenkomst met klanten (account, assistent, facturen).</li>
<li>Namens het vakbedrijf vastleggen van een klusaanvraag, zodat het bedrijf de beller kan terugbellen.</li>
<li>Wettelijke plicht (administratie: 7 jaar voor facturen).</li>
<li>Gerechtvaardigd belang: beveiliging en het voorkomen van misbruik.</li>
</ul>
<h2>4. Hoe lang</h2>
<ul>
<li>Klusaanvragen: 12 maanden, daarna automatisch verwijderd. Eerder als het vakbedrijf opzegt (binnen 30 dagen).</li>
<li>Accountgegevens: zolang het abonnement loopt, plus 30 dagen.</li>
<li>Aanmeldingen zonder abonnement: 6 maanden.</li>
<li>Facturen: 7 jaar.</li>
</ul>
<h2>5. Wie helpt ons (subverwerkers)</h2>
<ul>
<li><b>Supabase</b>: database en servers, in Frankfurt (EU).</li>
<li><b>Retell AI</b> (Verenigde Staten): telefonie en spraakassistent. Doorgifte buiten de EU gebeurt op basis van de standaardcontractbepalingen van de Europese Commissie. Retell bewaart alleen basisgegevens van het gesprek; het taalmodel (Anthropic) en de stem (ElevenLabs) worden via Retell ingezet.</li>
<li><b>Mollie</b> (Nederland): betalingen.</li>
<li><b>Resend</b>: het versturen van e-mail.</li>
<li><b>Hosting van de website</b>.</li>
</ul>
<h2>6. Jouw rechten</h2>
<p>Je mag je gegevens inzien, laten verbeteren of verwijderen, bezwaar maken en een kopie vragen. Mail naar <?php echo esc_html( $kv_mail ); ?>; we reageren binnen een maand. Ben je het niet met ons eens, dan kun je een klacht indienen bij de Autoriteit Persoonsgegevens.</p>
<h2>7. Beveiliging</h2>
<p>Gegevens zijn per klant strikt gescheiden, verbindingen zijn versleuteld en alleen bevoegde systemen hebben toegang. Bij een datalek informeren we betrokkenen en, waar nodig, de Autoriteit Persoonsgegevens.</p>

<?php elseif ( 'voorwaarden' === $kv_doc ) : ?>
<h1>Algemene voorwaarden</h1>
<p>Deze voorwaarden gelden voor elk abonnement op KlusVanger, een dienst van Salesify (vof), KvK <?php echo esc_html( $kv_kvk ); ?>. KlusVanger is uitsluitend bedoeld voor bedrijven en zelfstandigen.</p>
<h2>1. De dienst</h2>
<p>KlusVanger beantwoordt oproepen die de klant naar KlusVanger doorschakelt, legt een klusaanvraag vast en stuurt die per e-mail, en bij spoed per sms, naar de klant. De assistent noemt geen prijzen en zegt geen afspraken toe. De klant blijft zelf verantwoordelijk voor het terugbellen, de afspraken en het werk.</p>
<h2>2. Proefperiode en abonnement</h2>
<ul>
<li>Een abonnement start met 14 dagen gratis. Zeg je binnen die periode op, dan betaal je niets.</li>
<li>Daarna loopt het abonnement per maand, met maandelijkse betaling vooraf via automatische incasso.</li>
<li>Prijzen staan op de website en zijn exclusief btw. Belminuten boven de bundel kosten € 0,30 per minuut; je krijgt vooraf bericht als je de grens nadert.</li>
<li>Prijswijzigingen melden we minstens 30 dagen vooraf; je mag dan per de ingangsdatum opzeggen.</li>
</ul>
<h2>3. Opzeggen</h2>
<p>Je kunt elke maand opzeggen, met ingang van de volgende maand. Na opzegging zet je zelf het doorschakelen uit. Wij verwijderen je gegevens volgens de privacyverklaring.</p>
<h2>4. Beschikbaarheid</h2>
<p>We doen ons best om KlusVanger altijd beschikbaar te houden, maar kunnen niet garanderen dat de dienst nooit uitvalt, bijvoorbeeld door storingen bij telefoon- of internetproviders. Bij een storing die langer dan 24 uur duurt, krijg je naar rato je abonnementsgeld terug.</p>
<h2>5. Aansprakelijkheid</h2>
<p>De assistent is een hulpmiddel. We zijn niet aansprakelijk voor gemiste opdrachten, onjuist genoteerde gegevens of gevolgschade. Onze totale aansprakelijkheid is beperkt tot het bedrag dat je in de 3 maanden voor de schade aan ons betaalde. Deze beperking geldt niet bij opzet of bewuste roekeloosheid.</p>
<h2>6. Veiligheid</h2>
<p>Bij gevaarsignalen (zoals gaslucht of brand) verwijst de assistent naar 112 of het storingsnummer. De assistent vervangt nooit hulpdiensten.</p>
<h2>7. Gebruik</h2>
<p>Je gebruikt KlusVanger niet voor onwettige doeleinden en informeert je klanten, bijvoorbeeld op je website, dat oproepen kunnen worden beantwoord door een digitale assistent.</p>
<h2>8. Privacy</h2>
<p>Voor gegevens van bellers is KlusVanger verwerker en jij verwerkingsverantwoordelijke. De verwerkersovereenkomst op deze website maakt deel uit van deze voorwaarden.</p>
<h2>9. Recht</h2>
<p>Op deze voorwaarden is Nederlands recht van toepassing.</p>

<?php else : ?>
<h1>Verwerkersovereenkomst</h1>
<p>Deze verwerkersovereenkomst hoort bij elk abonnement op KlusVanger en gaat in zodra het abonnement start. Partijen: de klant (verwerkingsverantwoordelijke) en Salesify vof, handelend onder de naam KlusVanger (verwerker).</p>
<h2>1. Onderwerp</h2>
<p>De verwerker verwerkt persoonsgegevens van bellers uitsluitend om oproepen te beantwoorden, klusaanvragen vast te leggen en aan de klant door te geven, volgens de schriftelijke instructies van de klant zoals vastgelegd in de dienst en de instellingen.</p>
<h2>2. Gegevens en betrokkenen</h2>
<p>Betrokkenen: mensen die de klant bellen. Gegevens: telefoonnummer, naam, adres of plaats, omschrijving van de vraag, spoed en aandachtspunten. Geen bijzondere persoonsgegevens worden gevraagd.</p>
<h2>3. Verplichtingen van de verwerker</h2>
<ul>
<li>Verwerkt alleen op instructie van de klant en gebruikt de gegevens niet voor eigen doeleinden.</li>
<li>Zorgt voor passende beveiliging: scheiding per klant, versleutelde verbindingen, toegang op basis van noodzaak, logging.</li>
<li>Houdt de gegevens geheim; medewerkers en systemen hebben alleen toegang waar dat nodig is.</li>
<li>Helpt de klant bij verzoeken van betrokkenen en bij een datalek.</li>
<li>Meldt een datalek zonder onredelijke vertraging, uiterlijk binnen 48 uur na ontdekking.</li>
</ul>
<h2>4. Subverwerkers</h2>
<p>De klant geeft toestemming voor de subverwerkers in de privacyverklaring: Supabase (EU), Retell AI (VS, met standaardcontractbepalingen; inclusief Anthropic en ElevenLabs via Retell), Resend en de websitehosting. Nieuwe subverwerkers melden we 30 dagen vooraf; de klant mag dan bezwaar maken en opzeggen.</p>
<h2>5. Bewaren en verwijderen</h2>
<p>Klusaanvragen worden na 12 maanden automatisch verwijderd, en binnen 30 dagen na het einde van het abonnement. Geluidsopnames en volledige gesprekken worden niet in de database van de verwerker bewaard.</p>
<h2>6. Audit</h2>
<p>De verwerker geeft de klant op verzoek de informatie die nodig is om naleving aan te tonen.</p>
<h2>7. Aansprakelijkheid en duur</h2>
<p>De aansprakelijkheid volgt de algemene voorwaarden. Deze overeenkomst loopt zolang de verwerker gegevens voor de klant verwerkt.</p>
<?php endif; ?>
</article>

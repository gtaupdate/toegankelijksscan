<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
/* Presentatie "KlusVanger in 2 minuten": 6 dia's, klikbaar, veegbaar, werkt zonder JavaScript als scrollrij. */
$kv_slides = array(
	array( 'Het probleem', 'Je staat op een klus. De telefoon gaat.', 'Je kunt niet opnemen. De beller krijgt je voicemail en belt de volgende vakman. Tot 85% van de mensen die niemand aan de lijn krijgen, belt niet terug.', 'stat', array( '85%', 'belt niet terug als niemand opneemt', 'Bron: CallRail, 2025' ) ),
	array( 'Zo werkt het', 'Neem je niet op? Dan neemt KlusVanger op.', 'Je zet één keer "doorschakelen bij niet opnemen" aan bij je telefoonaanbieder. Je eigen nummer blijft. Neem je zelf op, dan merk je niets.', 'flow', array( 'Klant belt jouw nummer', 'Jij neemt niet op binnen 20 seconden', 'KlusVanger neemt op met jouw bedrijfsnaam' ) ),
	array( 'Het gesprek', 'Een vriendelijke assistent die doorvraagt.', 'Hij vraagt wat er aan de hand is, waar, hoe dringend en op welk nummer je kunt terugbellen. Het nummer leest hij cijfer voor cijfer terug.', 'chat', array( 'Goedemiddag, Installatiebedrijf Jansen, u spreekt met de assistent. Waarmee kan ik helpen?', 'Ik heb water uit het plafond onder de badkamer.', 'Vervelend. Druppelt het nog? En wat is de postcode?' ) ),
	array( 'Wat jij krijgt', 'Binnen een minuut een complete klusaanvraag.', 'In je mail staat alles om terug te bellen of direct in te plannen. Is het spoed, dan krijg je meteen een sms.', 'bon', array( 'Lekkage', 'Water uit plafond onder badkamer, druppelt nog', '3561 AB Utrecht', 'Spoed: ja' ) ),
	array( 'Wat hij nooit doet', 'Geen prijzen, geen afspraken, geen risico.', 'De assistent noemt nooit prijzen en zegt geen tijden toe. Dat doe jij als je terugbelt. Ruikt iemand gas, dan krijgt de beller direct veiligheidsinstructies en het storingsnummer 0800-9009, of 112 bij gevaar.', 'list', array( 'Noemt nooit prijzen', 'Zegt nooit afspraken toe', 'Gasprotocol bij gaslucht', 'Gesprekken versleuteld opgeslagen in de EU' ) ),
	array( 'Kosten', 'Eén extra klus per maand en hij is terugverdiend.', 'Maandelijks opzegbaar, geen opstartkosten, en je regelt het in tien minuten.', 'price', array() ),
);
$kv_total = count( $kv_slides );
?>
<div class="kv-deck" data-kv-deck aria-roledescription="presentatie" aria-label="KlusVanger in 2 minuten">
	<div class="kv-deck__top">
		<span class="kv-eyebrow">KlusVanger in 2 minuten</span>
		<span class="kv-deck__count" aria-live="polite"><b data-kv-deck-now>1</b> / <?php echo (int) $kv_total; ?></span>
	</div>
	<div class="kv-deck__bar" aria-hidden="true"><span data-kv-deck-bar></span></div>
	<div class="kv-deck__track" data-kv-deck-track tabindex="0">
		<?php foreach ( $kv_slides as $i => $s ) : ?>
		<section class="kv-slide" id="dia-<?php echo (int) $i + 1; ?>" aria-roledescription="dia" aria-label="<?php echo (int) $i + 1; ?> van <?php echo (int) $kv_total; ?>: <?php echo esc_attr( $s[0] ); ?>">
			<div class="kv-slide__text">
				<span class="kv-slide__kicker"><?php echo esc_html( sprintf( '%02d', $i + 1 ) . ' · ' . $s[0] ); ?></span>
				<h3><?php echo esc_html( $s[1] ); ?></h3>
				<p><?php echo esc_html( $s[2] ); ?></p>
			</div>
			<div class="kv-slide__visual kv-slide__visual--<?php echo esc_attr( $s[3] ); ?>">
				<?php if ( 'stat' === $s[3] ) : ?>
					<b class="kv-slide__big"><?php echo esc_html( $s[4][0] ); ?></b><span><?php echo esc_html( $s[4][1] ); ?></span><small><?php echo esc_html( $s[4][2] ); ?></small>
				<?php elseif ( 'flow' === $s[3] ) : ?>
					<ol><?php foreach ( $s[4] as $step ) : ?><li><?php echo esc_html( $step ); ?></li><?php endforeach; ?></ol>
				<?php elseif ( 'chat' === $s[3] ) : ?>
					<?php foreach ( $s[4] as $j => $line ) : ?><p class="kv-bubble <?php echo $j % 2 ? 'kv-bubble--klant' : ''; ?>"><span><?php echo $j % 2 ? 'Klant' : 'KlusVanger'; ?></span><?php echo esc_html( $line ); ?></p><?php endforeach; ?>
				<?php elseif ( 'bon' === $s[3] ) : ?>
					<dl><?php foreach ( array( 'Klus', 'Wat er is', 'Plaats', 'Urgentie' ) as $j => $k ) : ?><div><dt><?php echo esc_html( $k ); ?></dt><dd><?php echo esc_html( $s[4][ $j ] ); ?></dd></div><?php endforeach; ?></dl>
				<?php elseif ( 'list' === $s[3] ) : ?>
					<ul><?php foreach ( $s[4] as $item ) : ?><li><?php echo kv_icon( 'check' ); ?><?php echo esc_html( $item ); ?></li><?php endforeach; ?></ul>
				<?php else : ?>
					<div class="kv-slide__prices">
						<div><span>Solo</span><b>€ 99</b><small>per maand · tot 100 gesprekken</small></div>
						<div><span>Team</span><b>€ 199</b><small>per maand · tot 300 gesprekken</small></div>
					</div>
					<a class="kv-btn kv-btn--primary" href="<?php echo esc_url( home_url( '/#aanmelden' ) ); ?>">14 dagen gratis proberen</a>
					<a class="kv-btn kv-btn--ghost" href="<?php echo esc_url( home_url( '/#probeer' ) ); ?>">Hoor zelf een gesprek</a>
				<?php endif; ?>
			</div>
		</section>
		<?php endforeach; ?>
	</div>
	<div class="kv-deck__nav">
		<button type="button" class="kv-deck__btn" data-kv-deck-prev aria-label="Vorige dia">←</button>
		<div class="kv-deck__dots"><?php for ( $i = 1; $i <= $kv_total; $i++ ) : ?><button type="button" data-kv-deck-dot="<?php echo (int) $i - 1; ?>" aria-label="Ga naar dia <?php echo (int) $i; ?>"></button><?php endfor; ?></div>
		<button type="button" class="kv-deck__btn kv-deck__btn--next" data-kv-deck-next aria-label="Volgende dia">Volgende →</button>
	</div>
</div>

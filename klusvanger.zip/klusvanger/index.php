<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="inhoud" class="kv-page">
	<div class="kv-wrap">
		<div class="kv-content">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<h1><?php the_title(); ?></h1>
			<?php the_content(); ?>
		<?php endwhile; else : ?>
			<h1>Niet gevonden</h1>
			<p>Deze pagina bestaat niet. <a href="<?php echo esc_url( home_url( '/' ) ); ?>">Terug naar KlusVanger</a>.</p>
		<?php endif; ?>
		</div>
	</div>
</main>
<?php get_footer();

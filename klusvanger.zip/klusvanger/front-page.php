<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
$kv_vd  = kv_vak_data();
$kv_bon = $kv_vd ? $kv_vd['bon'] : array( 'Lekkage', 'Water uit het plafond onder de badkamer, blijft druppelen', '3561 AB Utrecht', 'S. Jansen', true );
?>
<main id="inhoud">

<!-- HERO -->
<section class="kv-hero">
	<div class="kv-wrap kv-hero__grid">
		<div class="kv-hero__copy">
			<span class="kv-eyebrow"><?php echo esc_html( $kv_vd ? 'Voor ' . strtolower( $kv_vd['naam'] ) : 'Voor vakmensen die met hun handen werken' ); ?></span>
			<h1><?php echo esc_html( $kv_vd ? $kv_vd['hero'] : 'Je staat op een ladder. De telefoon gaat.' ); ?> <em>Die klus is niet weg.</em></h1>
			<p class="kv-lead">KlusVanger beantwoordt je telefoon als jij aan het werk bent. Binnen een minuut heb je een complete klusaanvraag in je mail. Spoed krijg je direct als sms.</p>
			<div class="kv-hero__cta">
				<a class="kv-btn kv-btn--primary" href="#aanmelden">14 dagen gratis proberen</a>
				<a class="kv-btn kv-btn--ghost" href="#probeer">Hoor hoe het werkt</a>
			</div>
			<ul class="kv-checks">
				<li><?php echo kv_icon( 'check' ); ?>Je eigen nummer blijft</li>
				<li><?php echo kv_icon( 'check' ); ?>Noemt nooit prijzen</li>
				<li><?php echo kv_icon( 'check' ); ?>Vanaf € 99 per maand</li>
			</ul>
		</div>

		<div class="kv-stage" aria-label="Voorbeeld van een aanvraag die je ontvangt">
			<div class="kv-notif" data-kv-notif>
				<div class="kv-notif__icon"><?php echo kv_icon( 'phone' ); ?></div>
				<div><b>Gemiste oproep opgevangen</b><span>06 1 · · · · · 78 · zojuist</span></div>
			</div>
			<article class="kv-bon" data-kv-herobon>
				<div class="kv-bon__head"><span class="kv-bon__title">Klusaanvraag</span><span class="kv-bon__nr">Nr. 0142 · voorbeeld</span></div>
				<dl>
					<dt>Klus</dt><dd><?php echo esc_html( $kv_bon[0] ); ?></dd>
					<dt>Wat er is</dt><dd><?php echo esc_html( $kv_bon[1] ); ?></dd>
					<dt>Plaats</dt><dd><?php echo esc_html( $kv_bon[2] ); ?></dd>
					<dt>Naam</dt><dd><?php echo esc_html( $kv_bon[3] ); ?></dd>
					<dt>Terugbellen</dt><dd>06 12 34 56 78</dd>
				</dl>
				<div class="kv-bon__foot"><?php if ( $kv_bon[4] ) : ?><span class="kv-stamp kv-stamp--spoed">Spoed</span><span class="kv-tag">sms naar wie dienst heeft</span><?php else : ?><span class="kv-stamp kv-stamp--ok">Offerteaanvraag</span><span class="kv-tag">per mail, binnen een minuut</span><?php endif; ?></div>
			</article>
		</div>
	</div>
</section>

<!-- VAKKEN -->
<nav class="kv-vakbar" aria-label="Kies je vak">
	<div class="kv-wrap kv-vakbar__in">
		<span class="kv-vakbar__label">Voor jouw vak:</span>
		<?php foreach ( kv_vakken() as $slug => $v ) : ?>
			<a class="kv-vakchip<?php echo kv_vak() === $slug ? ' is-active' : ''; ?>" href="<?php echo esc_url( home_url( '/' . $slug . '/' ) ); ?>"<?php echo kv_vak() === $slug ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $v['naam'] ); ?></a>
		<?php endforeach; ?>
	</div>
</nav>

<!-- PROBLEEM -->
<section class="kv-band" aria-labelledby="probleem-titel">
	<div class="kv-wrap">
		<div class="kv-band__head">
			<span class="kv-eyebrow">Het probleem</span>
			<h2 id="probleem-titel">Wie jou niet bereikt, belt de volgende.</h2>
		</div>
		<div class="kv-stats">
			<div class="kv-stat">
				<b>85%</b>
				<p>van de bellers die geen gehoor krijgen, belt niet terug.</p>
				<cite>Tot 85%. CallRail Benchmark Report 2025, Verenigde Staten, 1,1 miljoen leads.</cite>
			</div>
			<div class="kv-stat">
				<b>52%</b>
				<p>van de Nederlanders belt bij een dringend probleem direct een ander bedrijf als er niet wordt opgenomen.</p>
				<cite>Infopact, onderzoek onder 1.044 Nederlanders (2016).</cite>
			</div>
			<div class="kv-stat">
				<b>30.600</b>
				<p>openstaande vacatures, alleen al in de installatiebranche. Er is niemand extra om de telefoon op te nemen.</p>
				<cite>KBA Nijmegen voor Techniek Nederland, medio 2024.</cite>
			</div>
		</div>
	</div>
</section>

<!-- VOOR ELK VAK -->
<?php if ( ! $kv_vd ) : ?>
<section class="kv-section" id="vakken" aria-labelledby="vakken-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Voor elk vak</span>
			<h2 id="vakken-titel">Werk je met je handen? Dan mis je oproepen.</h2>
			<p class="kv-lead">KlusVanger stelt per vak de juiste vragen. Een slotenmaker wil weten of iemand buiten staat, een elektricien of er stroom uit is, een schilder welke klus en wanneer.</p>
		</div>
		<div class="kv-vakgrid">
			<?php foreach ( kv_vakken() as $slug => $v ) : ?>
			<a class="kv-vakcard" href="<?php echo esc_url( home_url( '/' . $slug . '/' ) ); ?>">
				<b><?php echo esc_html( $v['naam'] ); ?></b>
				<span><?php echo esc_html( $v['pijn'] ); ?></span>
				<em>Bekijk voor <?php echo esc_html( strtolower( $v['naam'] ) ); ?> →</em>
			</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<!-- ZO WERKT HET: presentatie in 2 minuten -->
<section class="kv-section" id="zo-werkt-het" aria-labelledby="werkt-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Zo werkt het</span>
			<h2 id="werkt-titel">KlusVanger in 2 minuten.</h2>
		</div>
		<?php get_template_part( 'template-parts/presentatie' ); ?>
	</div>
</section>

<!-- PROBEER -->
<section class="kv-section kv-section--sunk" id="probeer" aria-labelledby="probeer-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Probeer het zelf</span>
			<h2 id="probeer-titel">Speel een klant die belt.</h2>
			<p class="kv-lead">Kies een situatie en antwoord zoals een klant zou doen. Rechts zie je de klusaanvraag die jij zou krijgen. Dit is een voorbeeld met verzonnen gegevens; aan de telefoon praat de assistent gewoon.</p>
		</div>
		<div class="kv-demo">
			<div class="kv-phone">
				<div class="kv-phone__bar">
					<span class="kv-phone__who"><span class="kv-dot" aria-hidden="true"></span>Assistent van <span data-kv-bedrijf><?php echo esc_html( $kv_vd ? $kv_vd['bedrijf'] : 'Vakbedrijf De Vries' ); ?></span></span>
					<button type="button" class="kv-btn kv-btn--ghost" data-kv-restart style="min-height:36px;padding:.35em .8em;font-size:.85rem">Opnieuw</button>
				</div>
				<div class="kv-scen" data-kv-scen aria-label="Kies een situatie"></div>
				<div class="kv-log" data-kv-log aria-live="polite"></div>
				<div class="kv-reply">
					<div class="kv-chips" data-kv-chips></div>
					<form class="kv-replyform" data-kv-replyform>
						<label class="kv-sr" for="kv-reply">Jouw antwoord als beller</label>
						<input class="kv-input" id="kv-reply" autocomplete="off" placeholder="Typ je antwoord als beller">
						<button class="kv-btn kv-btn--primary" type="submit">Stuur</button>
					</form>
				</div>
			</div>
			<article class="kv-bon" data-kv-demobon aria-live="polite">
				<div class="kv-bon__head"><span class="kv-bon__title">Klusaanvraag</span><span class="kv-bon__nr">wordt ingevuld</span></div>
				<dl>
					<dt>Klus</dt><dd data-f="klus" class="is-empty">nog niet bekend</dd>
					<dt>Wat er is</dt><dd data-f="omschrijving" class="is-empty">nog niet bekend</dd>
					<dt>Plaats</dt><dd data-f="plaats" class="is-empty">nog niet bekend</dd>
					<dt>Naam</dt><dd data-f="naam" class="is-empty">nog niet bekend</dd>
					<dt>Terugbellen</dt><dd data-f="nummer" class="is-empty">nog niet bekend</dd>
					<dt>Let op</dt><dd data-f="letop" class="is-empty">niets</dd>
				</dl>
				<div class="kv-bon__foot" data-kv-bonfoot><span class="kv-tag">gesprek loopt</span></div>
			</article>
		</div>
	</div>
</section>

<!-- REKENHULP -->
<section class="kv-section" id="rekenhulp" aria-labelledby="reken-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Rekenhulp</span>
			<h2 id="reken-titel">Wat kosten gemiste oproepen jou?</h2>
			<p class="kv-lead">Vul je eigen getallen in. Kijk voor het aantal gemiste oproepen in de belgeschiedenis van je telefoon.</p>
		</div>
		<div class="kv-calc">
			<form class="kv-calc__in" data-kv-calc onsubmit="return false">
				<div class="kv-range">
					<div class="kv-range__top"><label for="kv-c-n">Gemiste oproepen van klanten per maand</label><output for="kv-c-n" data-o="n">20</output></div>
					<input type="range" id="kv-c-n" min="0" max="100" step="1" value="20">
				</div>
				<div class="kv-range">
					<div class="kv-range__top"><label for="kv-c-c">Hoeveel daarvan worden een opdracht</label><output for="kv-c-c" data-o="c">25%</output></div>
					<input type="range" id="kv-c-c" min="0" max="80" step="5" value="25">
				</div>
				<div class="kv-range">
					<div class="kv-range__top"><label for="kv-c-w">Wat je gemiddeld overhoudt aan een opdracht</label><output for="kv-c-w" data-o="w">€ 250</output></div>
					<input type="range" id="kv-c-w" min="50" max="2000" step="25" value="250">
				</div>
			</form>
			<div class="kv-calc__out" aria-live="polite">
				<span class="kv-eyebrow">Schatting per maand</span>
				<div class="kv-calc__big" data-kv-calc-out>€ 1.250</div>
				<dl class="kv-calc__rows">
					<div><dt>Opdrachten uit gemiste oproepen</dt><dd data-kv-calc-jobs>5</dd></div>
					<div><dt>KlusVanger Solo / Team</dt><dd>€ 99 / € 199</dd></div>
					<div><dt>Quitte bij (Team)</dt><dd data-kv-calc-be>1 opdracht</dd></div>
				</dl>
				<p class="kv-small">Een schatting op basis van jouw eigen getallen, geen belofte. Niet elke opgevangen oproep wordt een opdracht.</p>
			</div>
		</div>
	</div>
</section>

<!-- WEL EN NIET -->
<section class="kv-section kv-section--sunk" aria-labelledby="afspraken-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Duidelijke afspraken</span>
			<h2 id="afspraken-titel">De assistent doet wat jij wilt. En niet meer.</h2>
		</div>
		<div class="kv-split">
			<div class="kv-list kv-list--yes">
				<h3>Wel</h3>
				<ul>
					<li><?php echo kv_icon( 'check' ); ?><span>Zegt meteen dat het de digitale assistent van jouw bedrijf is.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Vraagt klus, spoed, plaats, naam en terugbelnummer, één vraag tegelijk.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Herhaalt het terugbelnummer ter controle.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Stuurt spoed direct door naar de monteur van dienst.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Noteert vragen die hij niet kan beantwoorden, zodat jij ze ziet.</span></li>
				</ul>
			</div>
			<div class="kv-list kv-list--no">
				<h3>Nooit</h3>
				<ul>
					<li><?php echo kv_icon( 'cross' ); ?><span>Prijzen, tarieven of levertijden noemen.</span></li>
					<li><?php echo kv_icon( 'cross' ); ?><span>Een afspraak bevestigen. Dat doe jij als je terugbelt.</span></li>
					<li><?php echo kv_icon( 'cross' ); ?><span>Een antwoord gokken. Bij twijfel noteert hij de vraag.</span></li>
					<li><?php echo kv_icon( 'cross' ); ?><span>Meer gegevens vragen dan nodig is om terug te bellen.</span></li>
				</ul>
			</div>
		</div>
		<div class="kv-safety">
			<div class="kv-safety__icon"><?php echo kv_icon( 'warn' ); ?></div>
			<div>
				<h3>Ruikt de beller gas?</h3>
				<p>Dan zegt de assistent dat de beller de woning direct moet verlaten, geen schakelaars of stekkers moet aanraken en geen vuur moet gebruiken. Daarna verwijst hij naar het landelijk storingsnummer gas en stroom, 0800-9009, en bij direct gevaar naar 112. Jij krijgt de melding ook.</p>
			</div>
		</div>
	</div>
</section>

<!-- VERGELIJK -->
<section class="kv-section" id="vergelijk" aria-labelledby="vergelijk-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Vergelijk</span>
			<h2 id="vergelijk-titel">Wat doe je nu met gemiste oproepen?</h2>
			<p class="kv-lead">Een voicemail luistert niemand terug. Een telefoonservice kent je vak niet. Een algemene AI-assistent moet je zelf instellen. KlusVanger is gemaakt voor vakmensen.</p>
		</div>
		<div class="kv-compare" role="region" aria-label="Vergelijkingstabel" tabindex="0">
			<table>
				<thead><tr><th scope="col"></th><th scope="col">Voicemail</th><th scope="col">Telefoonservice</th><th scope="col">Algemene AI-assistent</th><th scope="col" class="is-us">KlusVanger</th></tr></thead>
				<tbody>
					<tr><th scope="row">Neemt 24/7 op</th><td>Nee, bandje</td><td>Vaak alleen kantooruren</td><td>Ja</td><td class="is-us">Ja</td></tr>
					<tr><th scope="row">Kent jouw vak en stelt de juiste vragen</th><td>Nee</td><td>Nauwelijks</td><td>Alleen als je het zelf instelt</td><td class="is-us">Ja, per vak ingericht</td></tr>
					<tr><th scope="row">Herkent spoed, sms of doorverbinden</th><td>Nee</td><td>Soms</td><td>Soms</td><td class="is-us">Ja</td></tr>
					<tr><th scope="row">Veiligheid: gas, brand, 112</th><td>Nee</td><td>Wisselend</td><td>Meestal niet</td><td class="is-us">Standaard ingebouwd</td></tr>
					<tr><th scope="row">Complete klusaanvraag in je mail</th><td>Nee</td><td>Een kort bericht</td><td>Een samenvatting</td><td class="is-us">Binnen een minuut, met belknop</td></tr>
					<tr><th scope="row">Noemt nooit prijzen of afspraken</th><td>–</td><td>Afhankelijk van de medewerker</td><td>Moet je zelf regelen</td><td class="is-us">Vaste regel</td></tr>
					<tr><th scope="row">Instellen</th><td>–</td><td>Gesprek en contract</td><td>Uren uitzoeken</td><td class="is-us">10 minuten</td></tr>
					<tr><th scope="row">Kosten per maand</th><td>€ 0, maar je mist de klus</td><td>Vaak € 15–145 plus kosten per gesprek</td><td>€ 50–350, vaak per minuut</td><td class="is-us"><b>Vanaf € 99, per gesprek</b></td></tr>
				</tbody>
			</table>
		</div>
		<p class="kv-small" style="margin-top:.8rem">Ter vergelijking: een eigen telefonist kost al snel € 2.500 of meer per maand.</p>
	</div>
</section>

<!-- TUSSEN-CTA -->
<section class="kv-ctaband" aria-label="Probeer KlusVanger">
	<div class="kv-wrap kv-ctaband__in">
		<div><b>Eén klus per maand en hij is terugverdiend.</b><span>14 dagen gratis, daarna maandelijks opzegbaar. Je eigen nummer blijft.</span></div>
		<a class="kv-btn kv-btn--primary" href="#aanmelden">Start 14 dagen gratis</a>
	</div>
</section>

<!-- PRIJS -->
<section class="kv-section" id="prijs" aria-labelledby="prijs-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Prijzen</span>
			<h2 id="prijs-titel">14 dagen gratis. Daarna maandelijks opzegbaar.</h2>
			<p class="kv-lead">Geen opstartkosten. Je betaalt pas na de proefperiode, en alleen als je doorgaat.</p>
		</div>
		<div class="kv-plans">
			<div class="kv-plan">
				<span class="kv-eyebrow">Solo</span>
				<p class="kv-plan__for">Voor zelfstandigen en kleine bedrijven tot 4 personen.</p>
				<div class="kv-plan__price"><b>€ 99</b><span class="kv-small">per maand, excl. btw</span></div>
				<ul>
					<li><?php echo kv_icon( 'check' ); ?><span>Tot 100 opgevangen gesprekken per maand</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Klusaanvraag per mail binnen een minuut</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Spoed direct als sms naar jou</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Jouw bedrijfsnaam, klussen en werkgebied</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Je eigen nummer blijft</span></li>
				</ul>
				<a class="kv-btn kv-btn--ghost" href="#aanmelden" data-kv-plan="solo">Probeer Solo 14 dagen gratis</a>
			</div>
			<div class="kv-plan kv-plan--main">
				<span class="kv-plan__badge">Voor bedrijven met monteurs</span>
				<span class="kv-eyebrow">Team</span>
				<p class="kv-plan__for">Voor installatiebedrijven met 5 of meer mensen.</p>
				<div class="kv-plan__price"><b>€ 199</b><span class="kv-small">per maand, excl. btw</span></div>
				<ul>
					<li><?php echo kv_icon( 'check' ); ?><span>Tot 300 opgevangen gesprekken per maand</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Alles uit Solo</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Spoed direct doorverbinden met wie dienst heeft</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Meerdere nummers en vestigingen</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Maandoverzicht: oproepen, aanvragen en spoed</span></li>
				</ul>
				<a class="kv-btn kv-btn--primary" href="#aanmelden" data-kv-plan="team">Probeer Team 14 dagen gratis</a>
			</div>
		</div>
		<p class="kv-small" style="margin-top:1rem">Meer gesprekken dan in je pakket? Elk extra gesprek kost € 0,45. Je krijgt bericht voordat je de grens bereikt. Een gesprek telt pas als de assistent echt iets noteert.</p>
	</div>
</section>

<!-- PRIVACY -->
<section class="kv-section kv-section--sunk" aria-labelledby="privacy-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Privacy</span>
			<h2 id="privacy-titel">Netjes met de gegevens van jouw klanten.</h2>
		</div>
		<div class="kv-trust">
			<div>
				<h3>Alleen wat nodig is</h3>
				<p>We bewaren klus, plaats, naam, terugbelnummer en spoed. Geen opnames en geen volledige gespreksteksten.</p>
			</div>
			<div>
				<h3>Opslag in de EU</h3>
				<p>Klusaanvragen staan op servers in Frankfurt. De spraakverwerking loopt via een partner in de Verenigde Staten, met de modelcontractbepalingen van de EU.</p>
			</div>
			<div>
				<h3>De beller weet het</h3>
				<p>De assistent zegt aan het begin dat de beller een digitale assistent spreekt. Jij krijgt een verwerkersovereenkomst.</p>
			</div>
		</div>
	</div>
</section>

<!-- VRAGEN -->
<section class="kv-section" id="vragen" aria-labelledby="vragen-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Veelgestelde vragen</span>
			<h2 id="vragen-titel">Wat vakmensen ons vragen.</h2>
		</div>
		<div class="kv-faq">
			<details><summary>Mijn klanten willen een mens spreken.</summary><div><p>Dat snappen we. KlusVanger neemt alleen op als jij niet kunt. Het alternatief is je voicemail, en daar spreken de meeste bellers niets op in. De beller hoort direct dat het een assistent is en dat jij terugbelt.</p></div></details>
			<details><summary>Blijft mijn telefoonnummer hetzelfde?</summary><div><p>Ja. Je stelt bij je telefoonaanbieder in dat oproepen bij geen gehoor of in gesprek worden doorgeschakeld. We sturen je de stappen voor jouw aanbieder. Uitzetten kan altijd met één code.</p></div></details>
			<details><summary>Wat als de assistent iets niet begrijpt?</summary><div><p>Lukt het twee keer niet, dan noteert hij het als bericht. Het nummer waarmee is gebeld, krijg je altijd. Zo kun je altijd terugbellen.</p></div></details>
			<details><summary>Noemt hij prijzen of plant hij afspraken?</summary><div><p>Nee. Prijzen en planning bespreek jij als je terugbelt. De assistent noteert de vraag, zodat je weet wat de klant wil weten.</p></div></details>
			<details><summary>Werkt het ook 's avonds en in het weekend?</summary><div><p>Ja, de assistent neemt dag en nacht op. Je kiest zelf of spoed buiten werktijd ook als sms binnenkomt.</p></div></details>
			<details><summary>Hoe snel is het geregeld?</summary><div><p>Binnen een werkdag na je aanmelding staat jouw assistent klaar. Het doorschakelen instellen kost je ongeveer tien minuten; we sturen je de stappen voor jouw telefoonaanbieder.</p></div></details>
			<details><summary>Waarom betaal ik per gesprek en niet per minuut?</summary><div><p>Omdat jij weet hoeveel telefoontjes je mist, niet hoeveel minuten ze duren. Een gesprek telt alleen als de assistent echt iets noteert. Ophangers en lege oproepen tellen niet mee.</p></div></details>
			<details><summary>Kan de assistent doorverbinden bij spoed?</summary><div><p>Ja, in het Team-pakket. Bij echte spoed noteert de assistent eerst adres en naam en verbindt dan door met wie dienst heeft. Neemt die niet op, dan krijg je alles als bericht en sms.</p></div></details>
			<details><summary>Wat als iemand buiten mijn werkgebied belt?</summary><div><p>De assistent kent je werkgebied. Belt iemand van buiten, dan noteert hij de aanvraag wel, maar zet hij er bij "Let op" bij dat het buiten je werkgebied valt. Jij beslist.</p></div></details>
			<details><summary>Werkt het ook met een vaste lijn of VoIP?</summary><div><p>Ja. Bij mobiel zet je het zelf aan met een code. Bij een vaste lijn of VoIP-centrale stel je doorschakelen in bij je aanbieder; we sturen je de stappen.</p></div></details>
			<details><summary>Hoe test ik of hij echt goed is?</summary><div><p>Doe wat een klant doet: bel buiten werktijd, zeg dat er water uit het plafond komt of dat je gas ruikt, vraag wat het kost en of er vandaag iemand kan komen. Je hoort dat hij spoed herkent, veiligheid voorop zet en niets belooft wat jij niet kunt waarmaken.</p></div></details>
			<details><summary>Wat gebeurt er na de 14 dagen?</summary><div><p>Ga je door, dan start je abonnement automatisch: Solo € 99 of Team € 199 per maand, excl. btw. Wil je stoppen, dan zet je het doorschakelen uit en zeg je op voor dag 15. Je betaalt dan niets.</p></div></details>
			<details><summary>Kan ik opzeggen?</summary><div><p>Ja, maandelijks, met één klik in de mail die je elke maand krijgt. Daarna zet je het doorschakelen uit.</p></div></details>
		</div>
	</div>
</section>

<!-- AANMELDEN -->
<section class="kv-section kv-section--sunk" id="aanmelden" aria-labelledby="aanmelden-titel">
	<div class="kv-wrap kv-signup">
		<div>
			<span class="kv-eyebrow">Gratis proberen</span>
			<h2 id="aanmelden-titel" style="margin-top:.8rem">Probeer KlusVanger 14 dagen gratis.</h2>
			<ol class="kv-timeline">
				<li><b>Vandaag</b><span>Je vult het formulier in. Het kost een minuut.</span></li>
				<li><b>Dag 1</b><span>Je krijgt een mail om je assistent in te stellen en de automatische incasso te machtigen. Er wordt dan nog niets afgeschreven.</span></li>
				<li><b>Dag 1–14</b><span>Je zet doorschakelen aan en KlusVanger vangt je gemiste oproepen op. Gratis.</span></li>
				<li><b>Dag 15</b><span>Ga je door, dan start je abonnement. Stop je voor dag 15, dan betaal je niets.</span></li>
			</ol>
		</div>
		<div class="kv-signup__card">
			<form class="kv-form" data-kv-form="pilot" novalidate>
				<fieldset class="kv-full kv-planpick">
					<legend>Kies je pakket</legend>
					<label><input type="radio" name="plan" value="solo" checked> <span><b>Solo</b> € 99 per maand<small>tot 100 gesprekken</small></span></label>
					<label><input type="radio" name="plan" value="team"> <span><b>Team</b> € 199 per maand<small>tot 300 gesprekken + doorverbinden</small></span></label>
				</fieldset>
				<label>Je naam<input name="naam" required autocomplete="name"></label>
				<label>Bedrijfsnaam<input name="bedrijf" required autocomplete="organization"></label>
				<label>E-mailadres<input name="email" type="email" required autocomplete="email"></label>
				<label>Telefoonnummer<input name="telefoon" type="tel" autocomplete="tel"></label>
				<label class="kv-full">Je vak<select name="vak"><?php foreach ( kv_vakken() as $slug => $v ) : ?><option value="<?php echo esc_attr( $slug ); ?>"<?php selected( kv_vak() ? kv_vak() : 'installateurs', $slug ); ?>><?php echo esc_html( $v['naam'] ); ?></option><?php endforeach; ?><option value="anders">Ander vak</option></select></label>
				<label class="kv-hp" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>
				<label class="kv-full kv-check"><input type="checkbox" name="toestemming_contact" required> <span>KlusVanger mag mij mailen over mijn proefperiode en het instellen van mijn assistent.</span></label>
				<div class="kv-full"><button class="kv-btn kv-btn--primary" type="submit" style="width:100%">Start 14 dagen gratis</button></div>
				<p class="kv-full kv-small">Geen betaling nu. Lees onze <a href="<?php echo esc_url( kv_opt( 'kv_privacy', '/privacy' ) ); ?>">privacyverklaring</a> en <a href="<?php echo esc_url( kv_opt( 'kv_terms', '/voorwaarden' ) ); ?>">voorwaarden</a>.</p>
				<div class="kv-form__msg" data-kv-msg hidden></div>
			</form>
		</div>
	</div>
</section>

<!-- PARTNER -->
<section class="kv-section" aria-labelledby="partner-titel" style="padding-top:0">
	<div class="kv-wrap">
		<div class="kv-partner" data-kv-partner>
			<div style="display:flex;flex-direction:column;gap:.4rem;max-width:40rem">
				<h3 id="partner-titel">Bouw je websites voor vakmensen?</h3>
				<p>Bied KlusVanger aan je klanten aan en ontvang 20% van elk abonnement, zolang je klant betaalt.</p>
			</div>
			<button type="button" class="kv-btn kv-btn--ghost" data-kv-partner-open aria-expanded="false">Word partner</button>
			<div class="kv-partner__form">
				<form class="kv-form" data-kv-form="partner" novalidate style="margin-top:1rem">
					<label>Je naam<input name="naam" required autocomplete="name"></label>
					<label>Bedrijfsnaam<input name="bedrijf" required autocomplete="organization"></label>
					<label>E-mailadres<input name="email" type="email" required autocomplete="email"></label>
					<label>Telefoonnummer<input name="telefoon" type="tel" autocomplete="tel"></label>
					<label class="kv-hp" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>
					<label class="kv-full kv-check"><input type="checkbox" name="toestemming_contact" required> <span>KlusVanger mag mij mailen over het partnerprogramma.</span></label>
					<div class="kv-full"><button class="kv-btn kv-btn--primary" type="submit">Aanmelden als partner</button></div>
					<div class="kv-form__msg" data-kv-msg hidden></div>
				</form>
			</div>
		</div>
	</div>
</section>

</main>
<?php
get_footer();

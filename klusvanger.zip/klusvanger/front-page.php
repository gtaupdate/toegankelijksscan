<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main id="inhoud">

<!-- HERO -->
<section class="kv-hero">
	<div class="kv-wrap kv-hero__grid">
		<div class="kv-hero__copy">
			<span class="kv-eyebrow">Voor installateurs en loodgieters</span>
			<h1>Je ligt onder een gootsteen. De telefoon gaat. <em>Die klus is niet weg.</em></h1>
			<p class="kv-lead">KlusVanger beantwoordt je telefoon als jij aan het werk bent. Binnen een minuut heb je een complete klusaanvraag in je mail. Spoed krijg je direct als sms.</p>
			<div class="kv-hero__cta">
				<a class="kv-btn kv-btn--primary" href="#probeer">Probeer een gesprek</a>
				<a class="kv-btn kv-btn--ghost" href="#rekenhulp">Bereken wat je mist</a>
			</div>
			<ul class="kv-checks">
				<li><?php echo kv_icon( 'check' ); ?>Je eigen nummer blijft</li>
				<li><?php echo kv_icon( 'check' ); ?>Noemt nooit prijzen</li>
				<li><?php echo kv_icon( 'check' ); ?>Maandelijks opzegbaar</li>
			</ul>
		</div>

		<div class="kv-stage" aria-label="Voorbeeld van een aanvraag die je ontvangt">
			<div class="kv-notif" data-kv-notif>
				<div class="kv-notif__icon"><?php echo kv_icon( 'phone' ); ?></div>
				<div><b>Gemiste oproep opgevangen</b><span>06 1 · · · · · 78 · zojuist</span></div>
			</div>
			<article class="kv-bon" data-kv-herobon>
				<div class="kv-bon__head"><span class="kv-bon__title">Klusaanvraag</span><span class="kv-bon__nr">Nr. 0142 · voorbeeld</span></div>
				<dl>
					<dt>Klus</dt><dd>Lekkage</dd>
					<dt>Wat er is</dt><dd>Water uit het plafond onder de badkamer, blijft druppelen</dd>
					<dt>Plaats</dt><dd>3561 AB Utrecht</dd>
					<dt>Naam</dt><dd>S. Jansen</dd>
					<dt>Terugbellen</dt><dd>06 12 34 56 78</dd>
				</dl>
				<div class="kv-bon__foot"><span class="kv-stamp kv-stamp--spoed">Spoed</span><span class="kv-tag">sms naar monteur van dienst</span></div>
			</article>
		</div>
	</div>
</section>

<!-- PROBLEEM -->
<section class="kv-band" aria-labelledby="probleem-titel">
	<div class="kv-wrap">
		<div class="kv-band__head">
			<span class="kv-eyebrow">Het probleem</span>
			<h2 id="probleem-titel">Wie jou niet bereikt, belt de volgende.</h2>
		</div>
		<div class="kv-stats">
			<div class="kv-stat">
				<b>85%</b>
				<p>van de bellers die geen gehoor krijgen, belt niet terug.</p>
				<cite>Tot 85%. CallRail Benchmark Report 2025, Verenigde Staten, 1,1 miljoen leads.</cite>
			</div>
			<div class="kv-stat">
				<b>52%</b>
				<p>van de Nederlanders belt bij een dringend probleem direct een ander bedrijf als er niet wordt opgenomen.</p>
				<cite>Infopact, onderzoek onder 1.044 Nederlanders (2016).</cite>
			</div>
			<div class="kv-stat">
				<b>30.600</b>
				<p>openstaande vacatures in de installatiebranche. Er is niemand extra om de telefoon op te nemen.</p>
				<cite>KBA Nijmegen voor Techniek Nederland, medio 2024.</cite>
			</div>
		</div>
	</div>
</section>

<!-- ZO WERKT HET -->
<section class="kv-section" id="zo-werkt-het" aria-labelledby="werkt-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Zo werkt het</span>
			<h2 id="werkt-titel">Drie stappen. Jij hoeft niets te veranderen aan je werkdag.</h2>
		</div>
		<ol class="kv-steps">
			<li class="kv-step">
				<div class="kv-step__icon"><?php echo kv_icon( 'fwd' ); ?></div>
				<h3>Je zet doorschakelen aan</h3>
				<p>Bij geen gehoor of in gesprek gaat de oproep naar KlusVanger. Instellen kost tien minuten. Je nummer blijft gewoon van jou.</p>
			</li>
			<li class="kv-step">
				<div class="kv-step__icon"><?php echo kv_icon( 'talk' ); ?></div>
				<h3>KlusVanger neemt op</h3>
				<p>De assistent zegt dat hij de digitale assistent van jouw bedrijf is. Hij vraagt wat er aan de hand is, of het spoed is, de plaats, de naam en het terugbelnummer.</p>
			</li>
			<li class="kv-step">
				<div class="kv-step__icon"><?php echo kv_icon( 'bon' ); ?></div>
				<h3>Jij krijgt de klusaanvraag</h3>
				<p>Binnen een minuut staat alles in je mail. Bij spoed krijgt de monteur van dienst direct een sms. Jij belt terug wanneer het jou uitkomt.</p>
			</li>
		</ol>
	</div>
</section>

<!-- PROBEER -->
<section class="kv-section kv-section--sunk" id="probeer" aria-labelledby="probeer-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Probeer het zelf</span>
			<h2 id="probeer-titel">Speel een klant die belt.</h2>
			<p class="kv-lead">Kies een situatie en antwoord zoals een klant zou doen. Rechts zie je de klusaanvraag die jij zou krijgen. Dit is een voorbeeld met verzonnen gegevens; aan de telefoon praat de assistent gewoon.</p>
		</div>
		<div class="kv-demo">
			<div class="kv-phone">
				<div class="kv-phone__bar">
					<span class="kv-phone__who"><span class="kv-dot" aria-hidden="true"></span>Assistent van Installatiebedrijf De Vries</span>
					<button type="button" class="kv-btn kv-btn--ghost" data-kv-restart style="min-height:36px;padding:.35em .8em;font-size:.85rem">Opnieuw</button>
				</div>
				<div class="kv-scen" data-kv-scen aria-label="Kies een situatie"></div>
				<div class="kv-log" data-kv-log aria-live="polite"></div>
				<div class="kv-reply">
					<div class="kv-chips" data-kv-chips></div>
					<form class="kv-replyform" data-kv-replyform>
						<label class="kv-sr" for="kv-reply">Jouw antwoord als beller</label>
						<input class="kv-input" id="kv-reply" autocomplete="off" placeholder="Typ je antwoord als beller">
						<button class="kv-btn kv-btn--primary" type="submit">Stuur</button>
					</form>
				</div>
			</div>
			<article class="kv-bon" data-kv-demobon aria-live="polite">
				<div class="kv-bon__head"><span class="kv-bon__title">Klusaanvraag</span><span class="kv-bon__nr">wordt ingevuld</span></div>
				<dl>
					<dt>Klus</dt><dd data-f="klus" class="is-empty">nog niet bekend</dd>
					<dt>Wat er is</dt><dd data-f="omschrijving" class="is-empty">nog niet bekend</dd>
					<dt>Plaats</dt><dd data-f="plaats" class="is-empty">nog niet bekend</dd>
					<dt>Naam</dt><dd data-f="naam" class="is-empty">nog niet bekend</dd>
					<dt>Terugbellen</dt><dd data-f="nummer" class="is-empty">nog niet bekend</dd>
					<dt>Let op</dt><dd data-f="letop" class="is-empty">niets</dd>
				</dl>
				<div class="kv-bon__foot" data-kv-bonfoot><span class="kv-tag">gesprek loopt</span></div>
			</article>
		</div>
	</div>
</section>

<!-- REKENHULP -->
<section class="kv-section" id="rekenhulp" aria-labelledby="reken-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Rekenhulp</span>
			<h2 id="reken-titel">Wat kosten gemiste oproepen jou?</h2>
			<p class="kv-lead">Vul je eigen getallen in. Kijk voor het aantal gemiste oproepen in de belgeschiedenis van je telefoon.</p>
		</div>
		<div class="kv-calc">
			<form class="kv-calc__in" data-kv-calc onsubmit="return false">
				<div class="kv-range">
					<div class="kv-range__top"><label for="kv-c-n">Gemiste oproepen van klanten per maand</label><output for="kv-c-n" data-o="n">20</output></div>
					<input type="range" id="kv-c-n" min="0" max="100" step="1" value="20">
				</div>
				<div class="kv-range">
					<div class="kv-range__top"><label for="kv-c-c">Hoeveel daarvan worden een opdracht</label><output for="kv-c-c" data-o="c">25%</output></div>
					<input type="range" id="kv-c-c" min="0" max="80" step="5" value="25">
				</div>
				<div class="kv-range">
					<div class="kv-range__top"><label for="kv-c-w">Wat je gemiddeld overhoudt aan een opdracht</label><output for="kv-c-w" data-o="w">€ 250</output></div>
					<input type="range" id="kv-c-w" min="50" max="2000" step="25" value="250">
				</div>
			</form>
			<div class="kv-calc__out" aria-live="polite">
				<span class="kv-eyebrow">Schatting per maand</span>
				<div class="kv-calc__big" data-kv-calc-out>€ 1.250</div>
				<dl class="kv-calc__rows">
					<div><dt>Opdrachten uit gemiste oproepen</dt><dd data-kv-calc-jobs>5</dd></div>
					<div><dt>KlusVanger per maand</dt><dd>€ 299</dd></div>
					<div><dt>Quitte bij</dt><dd data-kv-calc-be>1,2 opdracht</dd></div>
				</dl>
				<p class="kv-small">Een schatting op basis van jouw eigen getallen, geen belofte. Niet elke opgevangen oproep wordt een opdracht.</p>
			</div>
		</div>
	</div>
</section>

<!-- WEL EN NIET -->
<section class="kv-section kv-section--sunk" aria-labelledby="afspraken-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Duidelijke afspraken</span>
			<h2 id="afspraken-titel">De assistent doet wat jij wilt. En niet meer.</h2>
		</div>
		<div class="kv-split">
			<div class="kv-list kv-list--yes">
				<h3>Wel</h3>
				<ul>
					<li><?php echo kv_icon( 'check' ); ?><span>Zegt meteen dat het de digitale assistent van jouw bedrijf is.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Vraagt klus, spoed, plaats, naam en terugbelnummer, één vraag tegelijk.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Herhaalt het terugbelnummer ter controle.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Stuurt spoed direct door naar de monteur van dienst.</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Noteert vragen die hij niet kan beantwoorden, zodat jij ze ziet.</span></li>
				</ul>
			</div>
			<div class="kv-list kv-list--no">
				<h3>Nooit</h3>
				<ul>
					<li><?php echo kv_icon( 'cross' ); ?><span>Prijzen, tarieven of levertijden noemen.</span></li>
					<li><?php echo kv_icon( 'cross' ); ?><span>Een afspraak bevestigen. Dat doe jij als je terugbelt.</span></li>
					<li><?php echo kv_icon( 'cross' ); ?><span>Een antwoord gokken. Bij twijfel noteert hij de vraag.</span></li>
					<li><?php echo kv_icon( 'cross' ); ?><span>Meer gegevens vragen dan nodig is om terug te bellen.</span></li>
				</ul>
			</div>
		</div>
		<div class="kv-safety">
			<div class="kv-safety__icon"><?php echo kv_icon( 'warn' ); ?></div>
			<div>
				<h3>Ruikt de beller gas?</h3>
				<p>Dan zegt de assistent dat de beller de woning direct moet verlaten, geen schakelaars of stekkers moet aanraken en geen vuur moet gebruiken. Daarna verwijst hij naar het landelijk storingsnummer gas en stroom, 0800-9009, en bij direct gevaar naar 112. Jij krijgt de melding ook.</p>
			</div>
		</div>
	</div>
</section>

<!-- PRIJS -->
<section class="kv-section" id="prijs" aria-labelledby="prijs-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Prijs</span>
			<h2 id="prijs-titel">Eén abonnement. Geen opstartkosten.</h2>
		</div>
		<div class="kv-pricing">
			<div class="kv-plan">
				<span class="kv-eyebrow">KlusVanger Team</span>
				<div class="kv-plan__price"><b>€ 299</b><span class="kv-small">per maand, excl. btw</span></div>
				<ul>
					<li><?php echo kv_icon( 'check' ); ?><span>600 belminuten per maand, ongeveer 200 gesprekken</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Klusaanvraag per mail binnen een minuut</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Spoed-sms naar de monteur van dienst</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Je eigen nummer blijft</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Jouw bedrijfsnaam, klussen en werkgebied</span></li>
					<li><?php echo kv_icon( 'check' ); ?><span>Maandelijks opzegbaar</span></li>
				</ul>
				<p class="kv-small">Meer dan 600 minuten in een maand? Elke extra minuut kost € 0,25. Je krijgt vooraf bericht als je in de buurt komt.</p>
			</div>
			<div class="kv-pilot">
				<span class="kv-eyebrow">Pilot voor de eerste 10 bedrijven</span>
				<b class="kv-pilot__price">€ 99</b>
				<ul>
					<li>De eerste maand voor € 99, daarna € 299 per maand.</li>
					<li>Niet tevreden binnen 30 dagen? Je krijgt de € 99 terug.</li>
					<li>In ruil vragen we een kort evaluatiegesprek en toestemming om geanonimiseerde resultaten te gebruiken.</li>
				</ul>
				<a class="kv-btn" href="#aanmelden">Pilot aanvragen</a>
			</div>
		</div>
	</div>
</section>

<!-- PRIVACY -->
<section class="kv-section kv-section--sunk" aria-labelledby="privacy-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Privacy</span>
			<h2 id="privacy-titel">Netjes met de gegevens van jouw klanten.</h2>
		</div>
		<div class="kv-trust">
			<div>
				<h3>Alleen wat nodig is</h3>
				<p>We bewaren klus, plaats, naam, terugbelnummer en spoed. Geen opnames en geen volledige gespreksteksten.</p>
			</div>
			<div>
				<h3>Opslag in de EU</h3>
				<p>Klusaanvragen staan op servers in Frankfurt. De spraakverwerking loopt via een partner in de Verenigde Staten, met de modelcontractbepalingen van de EU.</p>
			</div>
			<div>
				<h3>De beller weet het</h3>
				<p>De assistent zegt aan het begin dat de beller een digitale assistent spreekt. Jij krijgt een verwerkersovereenkomst.</p>
			</div>
		</div>
	</div>
</section>

<!-- VRAGEN -->
<section class="kv-section" id="vragen" aria-labelledby="vragen-titel">
	<div class="kv-wrap">
		<div class="kv-section__head">
			<span class="kv-eyebrow">Veelgestelde vragen</span>
			<h2 id="vragen-titel">Wat installateurs ons vragen.</h2>
		</div>
		<div class="kv-faq">
			<details><summary>Mijn klanten willen een mens spreken.</summary><div><p>Dat snappen we. KlusVanger neemt alleen op als jij niet kunt. Het alternatief is je voicemail, en daar spreken de meeste bellers niets op in. De beller hoort direct dat het een assistent is en dat jij terugbelt.</p></div></details>
			<details><summary>Blijft mijn telefoonnummer hetzelfde?</summary><div><p>Ja. Je stelt bij je telefoonaanbieder in dat oproepen bij geen gehoor of in gesprek worden doorgeschakeld. We sturen je de stappen voor jouw aanbieder. Uitzetten kan altijd met één code.</p></div></details>
			<details><summary>Wat als de assistent iets niet begrijpt?</summary><div><p>Lukt het twee keer niet, dan noteert hij het als bericht. Het nummer waarmee is gebeld, krijg je altijd. Zo kun je altijd terugbellen.</p></div></details>
			<details><summary>Noemt hij prijzen of plant hij afspraken?</summary><div><p>Nee. Prijzen en planning bespreek jij als je terugbelt. De assistent noteert de vraag, zodat je weet wat de klant wil weten.</p></div></details>
			<details><summary>Werkt het ook 's avonds en in het weekend?</summary><div><p>Ja, de assistent neemt dag en nacht op. Je kiest zelf of spoed buiten werktijd ook als sms binnenkomt.</p></div></details>
			<details><summary>Hoe snel is het geregeld?</summary><div><p>Binnen vijf werkdagen na je aanmelding staat jouw assistent klaar. Het doorschakelen instellen kost je ongeveer tien minuten.</p></div></details>
			<details><summary>Kan ik opzeggen?</summary><div><p>Ja, maandelijks. Je zet het doorschakelen uit en klaar.</p></div></details>
		</div>
	</div>
</section>

<!-- AANMELDEN -->
<section class="kv-section kv-section--sunk" id="aanmelden" aria-labelledby="aanmelden-titel">
	<div class="kv-wrap kv-signup">
		<div>
			<span class="kv-eyebrow">Pilot aanvragen</span>
			<h2 id="aanmelden-titel" style="margin-top:.8rem">Probeer het een maand voor € 99.</h2>
			<ol class="kv-timeline">
				<li><b>Vandaag</b><span>Je vult het formulier in. Het kost een minuut.</span></li>
				<li><b>Dag 1–2</b><span>Je krijgt de betaallink van € 99 en de vragen over je bedrijf, zodat we de assistent kunnen instellen.</span></li>
				<li><b>Dag 5</b><span>Je assistent staat klaar en je zet het doorschakelen aan.</span></li>
				<li><b>Dag 30</b><span>Kort evaluatiegesprek. Ga je door, dan wordt het € 299 per maand.</span></li>
			</ol>
		</div>
		<div class="kv-signup__card">
			<form class="kv-form" data-kv-form="pilot" novalidate>
				<label>Je naam<input name="naam" required autocomplete="name"></label>
				<label>Bedrijfsnaam<input name="bedrijf" required autocomplete="organization"></label>
				<label>Rechtsvorm<select name="rechtsvorm"><option value="bv">bv</option><option value="vof">vof</option><option value="eenmanszaak">eenmanszaak</option><option value="anders">anders</option></select></label>
				<label>Aantal monteurs<input name="monteurs" type="number" min="0" max="500" inputmode="numeric" value="4"></label>
				<label>E-mailadres<input name="email" type="email" required autocomplete="email"></label>
				<label>Telefoonnummer<input name="telefoon" type="tel" autocomplete="tel"></label>
				<label class="kv-full">Hoeveel oproepen mis je per week, ongeveer?<input name="gemist" type="number" min="0" max="1000" inputmode="numeric" placeholder="bijvoorbeeld 5"></label>
				<label class="kv-hp" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>
				<label class="kv-full kv-check"><input type="checkbox" name="toestemming_contact" required> <span>Ik vraag zelf een pilot aan. KlusVanger mag mij hierover mailen of bellen.</span></label>
				<label class="kv-full kv-check"><input type="checkbox" name="toestemming_anoniem"> <span>Ik vind het goed dat geanonimiseerde resultaten (aantallen, geen klantgegevens) worden gebruikt.</span></label>
				<div class="kv-full"><button class="kv-btn kv-btn--primary" type="submit" style="width:100%">Pilot aanvragen</button></div>
				<p class="kv-full kv-small">Lees onze <a href="<?php echo esc_url( kv_opt( 'kv_privacy', '/privacy' ) ); ?>">privacyverklaring</a>. Je zit nergens aan vast tot je de € 99 betaalt.</p>
				<div class="kv-form__msg" data-kv-msg hidden></div>
			</form>
		</div>
	</div>
</section>

<!-- PARTNER -->
<section class="kv-section" aria-labelledby="partner-titel" style="padding-top:0">
	<div class="kv-wrap">
		<div class="kv-partner" data-kv-partner>
			<div style="display:flex;flex-direction:column;gap:.4rem;max-width:40rem">
				<h3 id="partner-titel">Bouw je websites voor installateurs?</h3>
				<p>Bied KlusVanger aan je klanten aan en ontvang 20% van elk abonnement, zolang je klant betaalt.</p>
			</div>
			<button type="button" class="kv-btn kv-btn--ghost" data-kv-partner-open aria-expanded="false">Word partner</button>
			<div class="kv-partner__form">
				<form class="kv-form" data-kv-form="partner" novalidate style="margin-top:1rem">
					<label>Je naam<input name="naam" required autocomplete="name"></label>
					<label>Bedrijfsnaam<input name="bedrijf" required autocomplete="organization"></label>
					<label>E-mailadres<input name="email" type="email" required autocomplete="email"></label>
					<label>Telefoonnummer<input name="telefoon" type="tel" autocomplete="tel"></label>
					<label class="kv-hp" aria-hidden="true">Website<input name="website" tabindex="-1" autocomplete="off"></label>
					<label class="kv-full kv-check"><input type="checkbox" name="toestemming_contact" required> <span>KlusVanger mag mij mailen over het partnerprogramma.</span></label>
					<div class="kv-full"><button class="kv-btn kv-btn--primary" type="submit">Aanmelden als partner</button></div>
					<div class="kv-form__msg" data-kv-msg hidden></div>
				</form>
			</div>
		</div>
	</div>
</section>

</main>
<?php
get_footer();

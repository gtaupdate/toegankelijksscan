<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
/* Losse pagina /hoe-het-werkt/ voor wie via een link binnenkomt: alleen de presentatie en de vervolgstap. */
get_header(); ?>
<main id="inhoud" class="kv-section kv-presentatie-page">
	<div class="kv-wrap">
		<h1 class="kv-presentatie-page__title">Zo werkt KlusVanger</h1>
		<?php get_template_part( 'template-parts/presentatie' ); ?>
	</div>
</main>
<?php get_footer();

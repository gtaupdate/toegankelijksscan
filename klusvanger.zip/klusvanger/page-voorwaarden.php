<?php if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); $kv_doc = 'voorwaarden'; ?>
<main id="inhoud" class="kv-section"><div class="kv-wrap"><?php include get_template_directory() . '/template-parts/juridisch.php'; ?></div></main>
<?php get_footer();
